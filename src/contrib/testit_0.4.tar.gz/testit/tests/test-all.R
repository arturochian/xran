library(testit)
test_pkg('testit')
