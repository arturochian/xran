x <- strwidth('foo', 'inches')
y <- strheight('foo', 'inches')
par(mar = c(4,4,1,1))
plot(1)
