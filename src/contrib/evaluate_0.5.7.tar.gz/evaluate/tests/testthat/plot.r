plot(1:10)
